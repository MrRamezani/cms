// webpack.mix.js

let mix = require('laravel-mix');

mix.styles([
    'resources/admin/dist/style.css',
], 'public/css/all-admin.css')
    .scripts([
        'resources/admin/js/app.js',
        'resources/admin/js/views/main.js',
    ], 'public/js/all-admin.js');
